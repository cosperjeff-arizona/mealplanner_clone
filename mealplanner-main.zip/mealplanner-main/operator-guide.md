# Mise en Place Operator Guide
## Weekly Meal Plan Generation Process

**Purpose:** This guide allows anyone to create a weekly meal plan for the Mise en Place app by following a simple, standardized process.

**Time Required:** 30-60 minutes (depending on complexity and revisions)

---

## Prerequisites

Before starting, ensure you have:
- [ ] Access to ChatGPT, Claude, or another AI assistant
- [ ] The Master Prompt file (V1.6 or latest)
- [ ] Access to the GitHub repository
- [ ] Answers to the initiation questions prepared

---

## Part 1: Preparation (5-10 minutes)

### Step 1.1: Determine the Start Date
Identify what week you're planning for:
- **Format:** "Tuesday November 11, 2025" or "Sunday November 16, 2025"
- **Tip:** Meal plans typically start on Sunday or the first day you're planning dinners

### Step 1.2: Answer the Initiation Questions

Prepare answers to these questions before starting:

1. **Start date:** _______________
2. **Number of dinners needed:** _______________
3. **Schedule constraints:**
   - Busy nights: _______________
   - Nights eating out: _______________
   - Special events: _______________
4. **Recipe requests/cravings:** _______________
5. **Ingredients to use up:** _______________
6. **Holiday proximity (within 4 weeks)?** Yes / No
   - If yes, test dessert? Yes / No
   - Which dessert? _______________
7. **Include Daily Fuel plan?** Yes / No
8. **Daily Fuel preferences this week:** _______________
9. **Ingredients on hand for Daily Fuel:** _______________
10. **Special constraints for Daily Fuel:** _______________
11. **Adjust recurring Daily Fuel items?** _______________

**Pro Tip:** Keep a running list of pantry items, scheduled events, and cravings throughout the week to make this step faster.

---

## Part 2: Generate the Meal Plan (15-30 minutes)

### Step 2.1: Open Your AI Assistant
- Open ChatGPT, Claude, or your preferred AI
- Start a new conversation

### Step 2.2: Load the Master Prompt
- Copy the entire Master Prompt (V1.6 or latest)
- Paste it into the AI assistant
- The AI should respond by asking the Initiation Questions

### Step 2.3: Provide Your Answers
- Copy your prepared answers from Part 1
- Paste them into the conversation
- The AI will propose a draft meal plan

### Step 2.4: Review and Refine
Review the proposed plan and ask yourself:
- [ ] Does this fit our schedule?
- [ ] Are the recipes appropriate for our skill level?
- [ ] Do we have time to cook these meals?
- [ ] Are the ingredients realistic?
- [ ] Does the variety feel right?

**Common refinements:**
- "Can we swap [meal] for something quicker?"
- "This feels too ambitious for Tuesday - simpler option?"
- "Can we use [ingredient] in another recipe?"

Continue discussing until the plan feels right.

### Step 2.5: Confirm Generation
When you're satisfied with the plan:
- Type exactly: **"Geronimo!"**
- The AI will generate the JavaScript file
- DO NOT say "Geronimo!" until you're completely happy with the plan

---

## Part 2B: Update an Existing Meal Plan (Alternative Flow)

### When to Use This
Use the update flow when you need to modify an already-deployed plan:
- Schedule changed after deployment
- Need to swap a meal due to missing ingredients or preferences
- Someone got sick, need simpler meals
- Restaurant plans fell through, need to add a meal
- Want to adjust Daily Fuel for specific days

### Step 2B.1: Gather Update Information

Before starting, have this information ready:
- [ ] Which week needs updating? (date: YYYY-MM-DD)
- [ ] Access to the current plan file
- [ ] Specific changes needed (be as detailed as possible)

### Step 2B.2: Start Update Process

1. Open your AI assistant (ChatGPT, Claude, etc.)
2. Paste the entire Master Prompt (V1.7 or latest)
3. When asked: **"Is this request for: A) New plan or B) Update?"**
4. Answer: **"B - Update existing plan"**

### Step 2B.3: Provide the Current Plan

You have two options for sharing the current plan:

**Option A - Upload File (Recommended):**
1. Go to your GitHub repository
2. Navigate to `data/plan-YYYY-MM-DD.js`
3. Click "Raw" button to see the raw file
4. Right-click → "Save As" to download
5. Upload the file to your AI assistant

**Option B - Copy/Paste:**
1. Go to your GitHub repository
2. Navigate to `data/plan-YYYY-MM-DD.js`
3. Click the file to open it
4. Copy all content (Ctrl+A, Ctrl+C)
5. Paste into the AI conversation

### Step 2B.4: Specify Your Changes

Be specific about what needs to change. Good examples:

**Meal Swaps:**
- "Swap Tuesday's chicken soup for grilled steak tacos - I'll be home early and want to use the grill"
- "Replace Thursday's pasta with something faster - 20 minutes or less"

**Adding Meals:**
- "Add a Friday dinner - our restaurant plans fell through"
- "Add Monday meal - we're not going out after all"

**Removing Meals:**
- "Remove Wednesday dinner - we're eating out now"
- "Take out Saturday - keeping it simple, ordering pizza"

**Daily Fuel Changes:**
- "Update Daily Fuel for Thursday and Friday only - need higher protein those days"
- "Change Tuesday breakfast from SEC to overnight oats"

**Multiple Changes:**
- "Swap Tuesday dinner AND update shopping list for the change"
- "Remove Wednesday, add Friday, adjust Daily Fuel for both days"

### Step 2B.5: Review Proposed Changes

The AI will show you:
- What will be removed/changed
- What will be added/updated
- Suggested updates to shopping list
- Suggested updates to prep tasks
- Any Daily Fuel adjustments

**Review carefully:**
- [ ] Changes are what you requested
- [ ] Shopping list updates make sense
- [ ] Prep tasks are appropriate
- [ ] Daily Fuel adjustments are reasonable
- [ ] Unchanged days remain intact

Request modifications if needed, then confirm with **"Geronimo!"**

### Step 2B.6: Replace the Existing File

**CRITICAL: You're REPLACING the file, not creating a new one!**

**In GitHub:**
1. Navigate to your repository
2. Go to `data/plan-YYYY-MM-DD.js` (the existing file)
3. Click the **pencil icon** (Edit this file)
4. Select all content (Ctrl+A) and delete
5. Paste the complete new content from the AI
6. Scroll down to commit section
7. Add commit message:
   - Good: "Update Nov 16 plan - swap Tuesday meal, update shopping"
   - Bad: "update" or "changes"
8. Click **"Commit changes"**

**DO NOT:**
- ❌ Create a new file with a different name
- ❌ Change the file name
- ❌ Keep both the old and new versions
- ❌ Modify weeks.js (no changes needed for updates)

### Step 2B.7: Verify Deployment

1. Wait 1-2 minutes for deployment
2. **Hard refresh** your browser (Ctrl+Shift+R or Cmd+Shift+R)
3. Navigate to the updated week in the dropdown
4. Verify changes appear correctly:
   - [ ] Changed meals show new content
   - [ ] Unchanged meals are still there
   - [ ] Shopping list reflects all meals (old and new)
   - [ ] Recipe pages work correctly

### Troubleshooting Updates

**Problem: Changes don't appear after deployment**
- Hard refresh browser (Ctrl+Shift+R)
- Clear browser cache
- Check that you edited the correct file
- Verify the file was committed successfully

**Problem: Entire week is broken/blank**
- Likely a syntax error in the updated file
- Check browser console (F12 → Console) for errors
- Review the file in GitHub for obvious issues
- May need to regenerate the update

**Problem: Unchanged days are different now**
- The AI may have accidentally modified preserved content
- Re-upload the original file
- Try the update again with clearer instructions: "Only change Tuesday, leave everything else exactly as-is"

---

## Part 3: Validate the Generated File (5-10 minutes)

### Step 3.1: Copy the Generated File
- The AI will output a JavaScript file
- Copy the entire file (from first comment to `window.planData = planData;`)

### Step 3.2: Visual Inspection Checklist

Before uploading, quickly scan the file and verify:

**File Format:**
- [ ] First line is a comment (starts with `//`)
- [ ] Starts with `const planData = {`
- [ ] Ends with `window.planData = planData;`

**Day Names:**
- [ ] All day names are lowercase (sunday, monday, tuesday, etc.)
- [ ] No typos in day names

**Structure:**
- [ ] All `{` braces have matching `}`
- [ ] All `[` brackets have matching `]`
- [ ] No obvious missing commas
- [ ] Strings use double quotes `"` consistently

**Content:**
- [ ] `weekOf` date matches your start date (YYYY-MM-DD format)
- [ ] Number of planned meals matches request
- [ ] momDaily includes all 7 days
- [ ] Shopping list has items in all categories

**Shopping Categories:**
Must use these exact names:
- [ ] "Produce"
- [ ] "Meat & Deli"
- [ ] "Dairy & Eggs"
- [ ] "Bakery & Grains"
- [ ] "Pantry"
- [ ] "Frozen"

### Step 3.3: Optional - Validate with Code Editor

For extra confidence (optional but recommended):
1. Paste the file into VS Code, Sublime Text, or any code editor
2. Save as `.js` file
3. Check for red squiggly lines or syntax errors
4. If you see errors, note them and ask the AI to fix

---

## Part 4: Deploy to GitHub (10-15 minutes)

### Step 4.1: Create the Plan File

1. Navigate to your GitHub repository
2. Go to the `data/` folder
3. Click **"Add file"** → **"Create new file"**
4. Name the file: `plan-YYYY-MM-DD.js`
   - Example: `plan-2025-11-11.js`
   - Use the start date of your meal plan
5. Paste the entire generated file content
6. **Important:** Scroll down and add a commit message
   - Example: "Add meal plan for week of Nov 11, 2025"
7. Click **"Commit new file"**

### Step 4.2: Update weeks.js

1. In GitHub, navigate to `data/weeks.js`
2. Click the **pencil icon** (Edit this file)
3. Add a new entry to the `availableWeeks` array:

```javascript
{
  id: "2025-11-11",
  label: "November 11, 2025",
  file: "plan-2025-11-11.js",
  startDate: "2025-11-11"
}
```

**Important Notes:**
- Add this entry at the END of the array (before the closing `]`)
- Make sure there's a comma after the previous entry
- Use the SAME date format as your filename
- Match the `file` name exactly

4. Update the `defaultWeek` at the bottom:

```javascript
const defaultWeek = availableWeeks[availableWeeks.length - 1].id;
```

This automatically sets the newest week as the default.

5. Add commit message: "Add week of Nov 11 to weeks index"
6. Click **"Commit changes"**

### Step 4.3: Wait for Deployment

- GitHub Pages takes 1-2 minutes to deploy
- Vercel (if using) takes 30-60 seconds
- You'll see a yellow dot next to your commit while it's building
- Green checkmark means deployment succeeded

---

## Part 5: Verification (5 minutes)

### Step 5.1: Open Your Live Site

Visit your meal planning site:
- GitHub Pages: `https://[username].github.io/[repo-name]/`
- Vercel: `https://[project-name].vercel.app/`

### Step 5.2: Verify the New Week Loaded

- [ ] Check the week navigation dropdown
- [ ] Your new week should appear in the list
- [ ] Select your new week from the dropdown
- [ ] The page should update with your new plan

### Step 5.3: Spot-Check Content

Click through and verify:
- [ ] **Weekly View:** All planned days show correctly
- [ ] **Recipes:** Click on a recipe - ingredients and steps appear
- [ ] **Shopping List:** Items are organized by category
- [ ] **Prep:** Prep tasks are listed
- [ ] **Daily Fuel cards:** All days have breakfast/lunch/snacks (if enabled)

### Step 5.4: Test on Mobile

- [ ] Open the site on your phone
- [ ] Verify it displays correctly
- [ ] Navigation works
- [ ] Can access recipes easily

---

## Troubleshooting

### Problem: New week doesn't appear in dropdown

**Possible causes:**
1. `weeks.js` wasn't updated correctly
2. Syntax error in `weeks.js` (missing comma, wrong brackets)
3. File name doesn't match the entry in `weeks.js`

**Solution:**
- Check `weeks.js` in GitHub for errors
- Verify the new week entry exists
- Make sure file name matches exactly

### Problem: Page loads but shows "No data" or errors

**Possible causes:**
1. Syntax error in the plan file
2. File name format incorrect
3. Missing `window.planData = planData;` at the end

**Solution:**
- Check browser console for JavaScript errors (F12 → Console tab)
- Go back to the generated file and look for syntax errors
- Ask the AI to regenerate with corrections

### Problem: Some recipes or sections are blank

**Possible causes:**
1. Missing data in the generated file
2. Incorrect object structure

**Solution:**
- Open the plan file in GitHub and verify the section has data
- Check that day names are lowercase
- Verify object structure matches template

### Problem: Shopping list categories missing or wrong

**Possible causes:**
1. Category names don't match exactly
2. Items not formatted correctly

**Solution:**
- Category names must be EXACT (case-sensitive):
  - "Produce", "Meat & Deli", "Dairy & Eggs", "Bakery & Grains", "Pantry", "Frozen"
- Each item must use format: `{ text: "Item name", checked: false }`

---

## Tips for Success

### For Faster Future Plans:
- **Keep a running list** of cravings and requests during the week
- **Track pantry items** that need using up
- **Note busy nights** as soon as they're scheduled
- **Prep answers in advance** - saves 5-10 minutes

### For Better Consistency:
- **Use the same AI assistant** each week when possible
- **Reference previous weeks** that worked well
- **Keep the Master Prompt updated** with new preferences
- **Don't skip validation steps** - they catch 90% of errors

### For Easier Collaboration:
- **Save your answers file** - family members can review and edit
- **Share the generated file** before deploying - get buy-in
- **Document special requests** - "remember I don't like X"
- **Create a family calendar** of busy nights to reference

---

## Quick Reference Checklist

Use this for rapid weekly generation:

```
□ Prepare answers to initiation questions
□ Load Master Prompt into AI
□ Provide answers
□ Review and refine plan
□ Confirm with "Geronimo!"
□ Copy generated file
□ Visual validation (file format, day names, structure)
□ Create plan-YYYY-MM-DD.js in GitHub
□ Update weeks.js with new entry
□ Wait for deployment (1-2 min)
□ Verify site loads new week
□ Spot-check: recipes, shopping, prep
□ Test on mobile
□ Done! 🎉
```

---

## Appendix: Example Answer File

Save this as a template and fill it out each week:

```
MEAL PLAN ANSWERS - Week of [DATE]
=====================================

1. Start Date: [Day, Month Date, Year]

2. Number of Dinners: [X]

3. Schedule:
   - Busy nights: 
   - Eating out: 
   - Special events: 

4. Recipe Requests:
   -
   -

5. Ingredients to Use Up:
   -
   -

6. Holiday Planning:
   - Within 4 weeks? Yes / No
   - Test dessert? Yes / No
   - Which dessert:

7. Daily Fuel: Yes / No

8. Daily Fuel Preferences:
   -

9. Daily Fuel Ingredients on Hand:
   -

10. Daily Fuel Constraints:
    -

11. Adjust Recurring Items:
    -

ADDITIONAL NOTES:
-
-
```

---

**Document Version:** 1.0  
**Last Updated:** November 2025  
**Compatible with:** Master Prompt V1.6+
