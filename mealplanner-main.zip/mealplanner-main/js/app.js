import { renderAll, renderFocus, todayKey, ORDER } from './components.js';
window.MEP = { renderAll, renderFocus, todayKey, ORDER };
